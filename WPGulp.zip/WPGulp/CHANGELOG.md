# Changelog

###Version 1.0.3
- FIX: Required `gulp-wp-pot`.
- FIX: Required `gulp-sort`.
- IMPROVEMENT: Better docs for Translation variables.

###Version 1.0.2 
- TASK: Image optimization `gulp images`
- TASK: WP POT Translation file generation `gulp translate`

###Version 1.0.1 
- BrowserSync
- LineEndings

### Version 1.0.0 
- First version
- CSS, JS, PHP and Watch Routines
